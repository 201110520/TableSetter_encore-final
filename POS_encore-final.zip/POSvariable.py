
loginVariable = {
    'host': 'untactoderdatabasedemo.cqnjsz5iib8e.ap-northeast-2.rds.amazonaws.com' ,
    'user':  'root',
    'password' : 'password',
    'db' : 'untact_order_db',
    'charset' : 'utf8',
    'port' : 3306
}

s3Variable = {
'ACCESS_KEY_ID' : 'AKIARGOYCUL5JB2QTQWJ',
'ACCESS_SECRT_KEY' : '+yX61aOjWNuVFmqpaTXSWaGVtB+fB45/6o3KCZ9x',
'BUCKET_NAME' : 'untact-order-system-images',
'region': 'ap-northeast-2'
}

global STORE_ID #로그인시 받아둔 매장번호
global POS_ID   #로그인시 받아둔 ID
global TABLE_NUM #테이블 개수

TABLE_NUM = 10
